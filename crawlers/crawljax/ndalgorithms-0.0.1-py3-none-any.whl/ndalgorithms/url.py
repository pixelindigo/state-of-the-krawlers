from .base import State
from collections import Counter
from urllib.parse import urlsplit, parse_qs


class UrlState(State):
    def __init__(self, driver, url, dom, forms, events, whole_path=False, query_enabled=False, **kwargs):
        super().__init__(driver, url, dom, forms, events, **kwargs)

        url = urlsplit(self.url)
        self.whole_path = whole_path
        self.query_enabled = query_enabled
        self.path = url.path
        self.query_keys = set(parse_qs(url.query).keys())

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, UrlState):
            if self.whole_path:
                return self.url == other.url
            if self.query_enabled:
                return self.path == other.path and self.query_keys == other.query_keys    
            return self.path == other.path

    def get_dist(self, other):
        if isinstance(other, UrlState):
            if self == other:
                return 0
            return 1
        return -1

    def __hash__(self):
        if self.whole_path:
            return hash(self.url)
        h = hash(self.path)
        if self.query_enabled:
            #h += hash(sorted(self.query_keys))
            h += sum(map(hash, self.query_keys))
        return h
