from .base import State
from urllib.parse import urlparse, urljoin

PROPERTIES = ['onclick', "onmouseover", "onabort", "onblur", "onchange", "onblclick", "onerror", "onfocus", "onkeydown",
                  "onkeypress", "onkeyup", "onmousedown", "onmousemove", "onmouseout", "onmouseup"]


class JAEKState(State):
    def __init__(self, *args, threshold, clickable_weight = 1.0, form_weight = 1.0, link_weight = 1.0, **kwargs):
        super().__init__(*args, **kwargs)
        self.threshold = threshold

        self.links, self.clickables = extract_links(self.driver, self.url)
        self.clickables += property_helper(self.driver)

        self.clickable_weight = clickable_weight
        self.form_weight = form_weight
        self.link_weight = link_weight

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, JAEKState):
            if self.dom == other.dom:
                return True

            clickable_weight = self.clickable_weight
            form_weight = self.form_weight
            link_weight = self.link_weight

            form_similarity = 0.0
            identical_forms = 0.0
            form_counter = len(self.forms) + len(other.forms)
            if form_counter > 0:
                for p1_form in self.forms:
                    is_in_other = False
                    for p2_form in other.forms:
                        if p1_form == p2_form:
                            is_in_other = True
                            break
                    if is_in_other:
                        identical_forms += 1.0
                        form_counter -= 1.0
                form_similarity = identical_forms / form_counter
            else:
                form_weight = 0.0

            link_similarity = 0.0
            identical_links = 0.0
            link_counter = len(self.links) + len(other.links)
            if link_counter > 0:
                for p1_link in self.links:
                    is_in_other = False
                    for p2_link in other.links:
                        if p1_link.url == p2_link.url:
                            is_in_other = True
                            break
                    if is_in_other:
                        identical_links += 1.0
                        link_counter -= 1.0
                link_similarity = identical_links / link_counter
            else:
                #logging.debug("Linkweight is 0.0")
                link_weight = 0.0

            clickable_similarity = 0.0
            identical_clickables = 0.0
            clickable_counter = len(self.clickables) + len(other.clickables)
            if clickable_counter > 0:
                for p1_clickable in self.clickables:
                    is_in_other = False
                    for p2_clickable in other.clickables:
                        if p1_clickable == p2_clickable:
                            is_in_other = True
                            break
                    if is_in_other:
                        identical_clickables += 1.0
                        clickable_counter -= 1.0
                clickable_similarity = identical_clickables / clickable_counter
            else:
                clickable_weight = 0

            sum_weight = clickable_weight + form_weight + link_weight
            similarity = clickable_weight * clickable_similarity + form_weight * form_similarity + link_weight * link_similarity
            if sum_weight > 0:
                return (1 - similarity / sum_weight) <= self.threshold
            else:
                return True
        return False


class Clickable():
    '''
    Models interesting element with events as attributes
    '''
    
    def __init__(self, event, tag, dom_address, id = None, html_class = None, clickable_depth = None, function_id = None):
        self.event = event
        self.tag = tag
        self.dom_address = dom_address
        self.id = id
        self.html_class = html_class
        self.clicked = False
        self.clickable_depth = clickable_depth
        self.function_id = function_id
    
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.tag == other.tag and self.dom_address == other.dom_address and self.event == other.event


class Link():
    
    def __init__(self, url, dom_address, html_id = "", html_class = ""):
        self.url = url 
        self.dom_address = dom_address
        self.html_id = html_id
        self.html_class = html_class
    
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.url == other.url

    def __ne__(self, other):
        return not self.__eq__(other) 

def property_helper(driver):
    all_elements = driver.find_elements_by_css_selector("*")
    result = []
    for element in all_elements:
        element_id = element.get_attribute("id") 
        element_class = element.get_attribute("class")
        element_dom_address = None
        for prop in PROPERTIES:
            if element.get_attribute(prop) is not None:
                if element_dom_address is None:
                    element_dom_address = driver.execute_script("return getXPath(arguments[0])", element)
                result.append(Clickable(prop, element.tag_name, element_dom_address, element_id, element_class, function_id="None"))
    return result

def extract_links(driver, requested_url):
    anchor_tags = driver.find_elements_by_tag_name("a")
    new_links, new_clickables = _extract_new_links_from_links(driver, anchor_tags, requested_url)
    iframes = driver.find_elements_by_tag_name("iframe") + driver.find_elements_by_tag_name("frame")
    new_links = new_links + extract_links_from_iframe(driver, iframes)
    return new_links, new_clickables

def _extract_new_links_from_links(driver, elements, requested_url):
    found_links = []
    new_clickables = []
    if(len(elements) == 0):
        #logging.debug("No links found...")
        return [], []
    else:
        for elem in elements:
            try:
                href = elem.get_attribute("href")
            except:
                print("Failed to process anchor")
                continue
            #logging.debug(str(type(elem)) + " href: " + str(href) + " Tagname: " + str(elem.tagName()))
            if href is None or href == "/" or href == requested_url or href == "": #or href[0] == '#':
                continue
            elif "javascript:" in href: #We assume it as clickable
                html_id = elem.get_attribute("id")
                html_class = elem.get_attribute("class")
                dom_address = driver.execute_script("return getXPath(arguments[0])", elem)
                event = href
                tag = "a"
                new_clickables.append(Clickable(event, tag, dom_address, html_id, html_class, None, None))
            elif "#" in href:
                html_id = elem.get_attribute("id")
                html_class = elem.get_attribute("class")
                dom_address = driver.execute_script("return getXPath(arguments[0])", elem)
                event = "click"
                tag = "a"
                new_clickables.append(Clickable(event, tag, dom_address, html_id, html_class, None, None))
            elif len(href) > 0:
                html_id = elem.get_attribute("id")
                html_class = elem.get_attribute("class")
                dom_address = driver.execute_script("return getXPath(arguments[0])", elem)
                url = href
                link = Link(url, dom_address, html_id, html_class)
                found_links.append(link)
            else:
                pass
                #logging.debug("Elem has attribute href: " + str(elem.get_attribute("href") + " and matches no criteria"))
    return found_links, new_clickables

def extract_links_from_iframe(driver, elements):
    found_links = []
    if len(elements) == 0:
        return []
    for element in elements:
        src = element.get_attribute("src")
        html_id = element.get_attribute("id")
        html_class = element.get_attribute("class")
        dom_address = driver.execute_script("return getXPath(arguments[0])", element)
        link = Link(src, dom_address, html_id, html_class)
        found_links.append(link)
    return found_links