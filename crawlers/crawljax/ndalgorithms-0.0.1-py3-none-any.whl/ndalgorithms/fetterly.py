from .base import State
from bs4 import BeautifulSoup
from bs4.element import Tag
from collections import deque

from rabin import Rabin
import re

RE_WORDS = re.compile(r'\w+')

def rabin(data):
    r = Rabin()
    r.update(data)
    return r.fingerprints()[0][2]

class FetterlyState(State):
    def __init__(self, *args, threshold, **kwargs):
        super().__init__(*args, **kwargs)

        # Merkator url-hashing
        self.hashed_url = rabin(self.url)

        # We canonicalize documents by removing HTML markup
        self.text = BeautifulSoup(self.dom, 'lxml').get_text().lower()
        # the shingle size is 5
        self.window = deque(maxlen=5)


    def dist(self, other):
        """Overrides the default implementation"""
        if isinstance(other, LuccaLevenshteinHtmlState):
            common_alphabet = sorted(self.alphabet | other.alphabet)
            seq_a = map(common_alphabet.index, self.tags)
            seq_b = map(common_alphabet.index, other.tags)

            return edit_distance(seq_a, seq_b) / max(len(self.tags), len(other.tags))

        return -1


    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, FetterlyState):
            # Merkator part
            if self.hashed_url == other.hashed_url:
                return True
            if self.dist(other) < self.threshold:
                return True
        return False
