from .base import State
from apted import APTED, Config
from bs4 import BeautifulSoup
from bs4.element import Tag
from collections import Counter

class CustomConfig(Config):
    
    def rename(self, a, b):
        return 1 if a.name != b.name else 0

    def children(self, node):
        return list(
                filter(lambda x: isinstance(x, Tag),
            node.children))

def get_child_nodes(node):
    return list(filter(lambda x: isinstance(x, Tag),
            node.children))


class DOMTree:

    def __init__(self, doc):
        self.doc = doc
        self.tokens = Counter()

    def prune(self, node=None):
        if node is None:
            node = self.doc
        children = {}

        for child in list(node.children):
            if not isinstance(child, Tag):
                continue
            child_token = self.prune(child)
            children[child_token] = child.extract()

        children = sorted(children.items())

        for _, child in children:
            node.append(child)

        token = f'<{node.name}{"".join([t for t, _ in children])}>'
        #node.token = token
        self.tokens[token] += 1
        return token

    def get_document_element(self):
        return self.doc

    def count_nodes(self):
        return self._count_nodes(self.doc)

    def _count_nodes(self, node):
        return sum(map(self._count_nodes, get_child_nodes(node))) + 1


class GeneralPathsState(State):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.domtree = DOMTree(BeautifulSoup(self.dom, 'lxml'))
        self.domtree.prune()
        self.nodes = self.domtree.count_nodes()
        self.tokens = set(self.domtree.tokens.keys())
        self.hash = sum(map(hash, sorted(self.tokens)))

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, GeneralPathsState):
            dom1 = self.domtree
            dom2 = other.domtree

            tokens_a = self.tokens
            tokens_b = other.tokens

            if len(tokens_a) == 0 and len(tokens_b) == 0:
                return False

            return tokens_a == tokens_b

    def get_dist(self, other):
        if isinstance(other, GeneralPathsState):
            if self == other:
                return 0
            return 1
        return -1

    def __hash__(self):
        return self.hash
