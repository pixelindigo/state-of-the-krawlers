from .base import State
from apted import APTED, Config
from bs4 import BeautifulSoup
from bs4.element import Tag
from collections import Counter

class CustomConfig(Config):
    
    def rename(self, a, b):
        return 1 if a.name != b.name else 0

    def children(self, node):
        return list(
                filter(lambda x: isinstance(x, Tag),
            node.children))

def get_child_nodes(node):
    return list(filter(lambda x: isinstance(x, Tag),
            node.children))


class DOMTree:

    def __init__(self, doc):
        self.doc = doc
        self.tokens = Counter()

    def prune(self, node=None):
        if node is None:
            node = self.doc
        children = {}

        for child in list(node.children):
            if not isinstance(child, Tag):
                continue
            child_token = self.prune(child)
            children[child_token] = child.extract()

        children = sorted(children.items())

        for _, child in children:
            node.append(child)

        token = f'<{node.name}{"".join([t for t, _ in children])}>'
        #node.token = token
        self.tokens[token] += 1
        return token

    def get_document_element(self):
        return self.doc

    def count_nodes(self):
        return self._count_nodes(self.doc)

    def _count_nodes(self, node):
        return sum(
                map(self._count_nodes, get_child_nodes(node)),
                start=1)


class PathsState(State):
    def __init__(self, *args, threshold, **kwargs):
        super().__init__(*args, **kwargs)

        self.threshold = threshold
        self.domtree = DOMTree(BeautifulSoup(self.dom, 'lxml'))
        self.domtree.prune()
        self.nodes = self.domtree.count_nodes()

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, PathsState):
            dom1 = self.domtree
            dom2 = other.domtree
            tokens = dom1.tokens + dom2.tokens

            tokens_a = set(filter(lambda x: tokens[x] > 1, dom1.tokens.keys()))
            tokens_b = set(filter(lambda x: tokens[x] > 1, dom2.tokens.keys()))

            if self.threshold is None:
                if len(tokens_a) == 0 and len(tokens_b) == 0:
                    apted = APTED(dom1.get_document_element(),
                                  dom2.get_document_element(),
                                  CustomConfig())
                    pruned_distance = apted.compute_edit_distance()
                    pruned_nodes1 = dom1.count_nodes()
                    pruned_nodes2 = dom2.count_nodes()
                    if pruned_distance / (pruned_nodes1 + pruned_nodes2) > 0.04116346242841695:
                        return False
                    return True
                else:
                    if len(tokens_a ^ tokens_b) > 0:
                        return False
                    return True

            pruned_nodes1 = len(tokens_a | tokens_b)
            pruned_nodes2 = 0
            pruned_distance = len(tokens_a ^ tokens_b)
            if pruned_nodes1 == 0:
                apted = APTED(dom1.get_document_element(),
                              dom2.get_document_element(),
                              CustomConfig())
                pruned_distance = apted.compute_edit_distance()
                pruned_nodes1 = dom1.count_nodes()
                pruned_nodes2 = dom2.count_nodes()
            pruned_distance /= pruned_nodes1 + pruned_nodes2
            return pruned_distance <= self.threshold
        return False