class State:

    def __init__(self, driver, url, dom, forms, events):
        self.driver = driver
        self.url = url
        self.dom = dom
        self.forms = forms
        self.events = events

        # should fix UnicodeEncodeError
        self.dom = self.dom.encode('utf-16','surrogatepass').decode('utf-16')

    def get_dist(self, other):
        return -1
