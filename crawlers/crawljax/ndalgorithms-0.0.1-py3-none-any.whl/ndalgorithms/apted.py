from .base import State
from apted import APTED, Config
from bs4 import BeautifulSoup
from bs4.element import Tag

class CustomConfig(Config):
    
    def rename(self, a, b):
        return 1 if a.name != b.name else 0

    def children(self, node):
        return list(
                filter(lambda x: isinstance(x, Tag),
            node.children))

def get_child_nodes(node):
    return list(filter(lambda x: isinstance(x, Tag),
            node.children))


class DOMTree:
    
    def __init__(self, doc):
        self.doc = doc
    
    def prune(self, node=None):
        if node is None:
            node = self.doc
        prev = None
        prev_node = None
        children = ''
        is_list = False
        for child in list(node.children):
            if not isinstance(child, Tag):
                continue
            next_child = self.prune(child)
            children += f' {next_child}'
            if next_child == prev:
                prev_node.extract()
                is_list = True
            elif is_list:
                is_list = False
                list_node = self.doc.new_tag('optlist')
                prev_node.wrap(
                    self.doc.new_tag('optlist'))

            prev = next_child
            prev_node = child
        if is_list:
            list_node = self.doc.new_tag('optlist')
            prev_node.wrap(
                self.doc.new_tag('optlist'))

        if prev is None:
            return node.name
        else:
            return f'<{node.name}{children}>'
    
    def get_document_element(self):
        return self.doc
    
    def count_nodes(self):
        return self._count_nodes(self.doc)
    
    def _count_nodes(self, node):
        return sum(map(self._count_nodes, get_child_nodes(node))) + 1


class APTEDState(State):
    def __init__(self, driver, url, dom, forms, events, threshold, prune=False, **kwargs):
        super().__init__(driver, url, dom, forms, events, **kwargs)

        self.threshold = threshold
        self.domtree = DOMTree(BeautifulSoup(self.dom, 'lxml'))
        if prune:
            self.domtree.prune()
        self.nodes = self.domtree.count_nodes()
        self.cache = {}

    def __eq__(self, other):
        return self.get_dist(other) <= self.threshold

    def get_dist(self, other):
        if isinstance(other, APTEDState):
            cached = self.cache.get(hash(other.dom), None)
            if cached is not None:
                return cached

            apted = APTED(self.domtree.get_document_element(),
                          other.domtree.get_document_element(),
                          CustomConfig())

            distance = apted.compute_edit_distance() / (self.nodes + other.nodes)
            self.cache[hash(other.dom)] = distance 

            return distance

    def __hash__(self):
        # don't know how to guarantee that equal aptedstates would have the same hash
        return 0
