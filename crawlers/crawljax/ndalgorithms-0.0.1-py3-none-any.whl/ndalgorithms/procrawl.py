from .base import State
from bs4 import BeautifulSoup
from bs4.element import Tag
from collections import deque


class ProcrawlState(State):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.soup = BeautifulSoup(self.dom, 'lxml')
        self.text = self.soup.get_text()

        self.buttons = set()
        self.links = set()

        self.traverse(deque(), self.soup)


    def traverse(self, path, el):
        if not isinstance(el, Tag):
            return

        if el.name == 'a':
            link = el.attrs.get('href', None)
            if link is not None:
                self.links.add(link)
            return
        elif el.name == 'button':
            self.buttons.add('/'.join(path))
            return
        path.append(el.name)
        for children in el.children:
            self.traverse(path, children)
        path.pop()

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, ProcrawlState):
            return self.text == other.text \
                    and self.links == other.links \
                    and self.buttons == other.buttons

    def get_dist(self, other):
        if isinstance(other, ProcrawlState):
            if self == other:
                return 0
            return 1
        return -1

    def __hash__(self):
        return hash(self.text) + sum(map(hash,self.links)) + sum(map(hash, self.buttons))
