from .base import State
from bs4 import BeautifulSoup
from bs4.element import Tag
from collections import deque

class PrefixTree:

    class Node:

        def __init__(self, data):
            self.data = data

    def __init__(self):
        pass

    def insert(self, vec):
        pass

class LigreState(State):
    def __init__(self, *args, threshold, **kwargs):
        super().__init__(*args, **kwargs)

        self.soup = BeautifulSoup(self.dom, 'lxml')

        self.tree = []

        self.traverse(deque(), self.soup)


    def traverse(self, path, el):
        if not isinstance(el, Tag):
            return

        if el.name == 'a':
            path.append(el.name)
            self.tree.append('/'.join(path))
            path.pop()
            return
        elif el.name == 'form':
            path.append(el.name)
            self.tree.append('/'.join(path))
            path.pop()
            return
        path.append(el.name)
        for children in el.children:
            self.traverse(path, children)
        path.pop()


    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, LigreState):
            return True

        return False
