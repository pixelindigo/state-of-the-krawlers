from .base import State
from bs4 import BeautifulSoup
from bs4.element import Tag


class LuccaLevenshteinHtmlState(State):
    def __init__(self, *args, threshold, **kwargs):
        super().__init__(*args, **kwargs)

        self.soup = BeautifulSoup(self.dom, 'lxml')

        self.tags = []
        self.traverse(self.soup)
        self.alphabet = set(self.tags)

        self.threshold = threshold


    def traverse(self, el):
        if not isinstance(el, Tag):
            return

        self.tag_sequence.append(el.name)
        for attr in el.attrs:
            self.tags += list(el.attrs)
        for child in el.children:
            self.traverse(child)
        self.tag_sequence.append('/' + el.name)

    def dist(self, other):
        """Overrides the default implementation"""
        if isinstance(other, LuccaLevenshteinHtmlState):
            common_alphabet = sorted(self.alphabet | other.alphabet)
            seq_a = map(common_alphabet.index, self.tags)
            seq_b = map(common_alphabet.index, other.tags)

            return edit_distance(seq_a, seq_b) / max(len(self.tags), len(other.tags))

        return -1


    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, LuccaLevenshteinHtmlState):
            if self.dist(other) < self.threshold:
                return True
        return False
