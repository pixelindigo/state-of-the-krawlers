from .base import State
import re

RE_COV_TIMESTAMP = re.compile(r'(\d+)\..{14}\..{8}\.serialized')

class DOMStrEqState(State):
    def __init__(self, driver, url, dom, forms, events, **kwargs):
        # remove arachnarium coverage stamp
        dom = RE_COV_TIMESTAMP.sub('', dom)
        super().__init__(driver, url, dom, forms, events, **kwargs)

    def __eq__(self, other):
        """Overrides the default implementation"""
        if isinstance(other, DOMStrEqState):
            return self.dom == other.dom

    def get_dist(self, other):
        if isinstance(other, DOMStrEqState):
            if self == other:
                return 0
            return 1
        return -1

    def __hash__(self):
        return hash(self.dom)
